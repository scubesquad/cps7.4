<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Services\CommonService;
use App\Services\DashboardService;
use Auth;
use App\Traits\SmsTrait;

class TestController extends Controller
{
    protected $commonService;
    protected $dashboardService;

    use SmsTrait;

    public function __construct(CommonService $commonService, DashboardService $dashboardService){
        // parent::__construct();
        // $this->commonService = $commonService;
        // $this->dashboardService = $dashboardService;
    }

    public function test(){

        $result = $this->sendSms('+917083008499','test');
        

    }
}
