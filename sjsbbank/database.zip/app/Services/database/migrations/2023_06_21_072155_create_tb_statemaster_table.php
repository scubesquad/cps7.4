<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tb_statemaster', function (Blueprint $table) {
            $table->integer('state_id', true);
            $table->string('state_name', 50)->nullable();
            $table->integer('country_id')->nullable();
            $table->string('state_code', 7)->nullable();
            $table->string('state_name_al', 4)->nullable();
            $table->integer('is_delete')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tb_statemaster');
    }
};
